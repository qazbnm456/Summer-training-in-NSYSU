#include <stdio.h>

/*
 * perl -e 'print "\xeb\xfe","A"x14,"\x10\x00\x00\x00",
 *                "\x28","\x60\xa0\x04\x08","\n"'
 */

char str[256];

struct pack{
  char buf[16];
  int i, j;
};

int main() {
  struct pack p;
  fgets(str, sizeof(str), stdin);
  for (p.i=0, p.j=0; str[p.i]!='\n'; ++p.i) {
    if (str[p.i]!=' ') {
      p.buf[p.j++] = str[p.i];
    }
  }
  p.buf[p.j] = 0;
  puts(p.buf);
}
