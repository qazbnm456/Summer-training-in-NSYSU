#include <stdio.h>

/*
 * perl -e 'print "\xeb\xfe","A"x20,"\xb6\x83\x04\x08"' | ./gets
 */

void hacked() {
  puts("Hacked!!");
}

int main() {
  char str[10];
  gets(str);
}
