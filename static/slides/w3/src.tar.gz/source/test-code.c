#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char **argv) {
  alarm(300);
  char buf[1024];
  char str[4096];
  FILE *f;
  int len, i;
  void (*code)();

  sprintf(buf, "objdump -M intel -d %s", argv[1]);
  system(buf);

  f = fopen(argv[1], "rb");
  fseek(f, 0, SEEK_END);
  len = ftell(f);
  fseek(f, 0x54, SEEK_SET);
  fread(str, len - 0x54, 1, f);
  fclose(f);

  puts("\nShellcode:");

  for (i=0; str[i]; ++i) {
    printf("%02x ", str[i]&0xff);
  }
  puts("\nExecution:");
  fflush(stdout);

  code = (void(*)())str;
  code();
  return 0;
}
